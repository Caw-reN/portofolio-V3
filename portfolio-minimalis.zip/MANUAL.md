# Dokumentasi & Panduan Deployment Portfolio Minimalis

File ini berisi penjelasan teknis mengenai struktur kode aplikasi, panduan untuk mengubah konten (teks, gambar, data), serta langkah-langkah untuk men-deploy aplikasi ini ke VPS (Virtual Private Server).

---

## 1. Penjelasan Struktur Kode

Aplikasi ini dibangun menggunakan **React** (Library UI), **Tailwind CSS** (Styling), dan **Framer Motion** (Animasi). Berikut adalah fungsi dari setiap file:

### Core Files
*   **`index.html`**: File utama yang dimuat browser. Berisi konfigurasi Tailwind CSS, Font (Inter), dan Import Map untuk memuat library React langsung dari CDN (esm.sh).
*   **`index.tsx`**: Titik masuk aplikasi React. File ini mencari elemen `#root` di HTML dan merender komponen `<App />`.
*   **`App.tsx`**: Mengatur **Routing** (navigasi halaman). Menentukan halaman mana yang muncul saat URL berubah (misal: `/` untuk Home, `/project/:id` untuk detail project).
*   **`types.ts`**: Definisi tipe data (TypeScript Interfaces). Ini memastikan data pengalaman, project, dan artikel memiliki struktur yang konsisten.
*   **`constants.tsx`** (PENTING): **Database** sederhana aplikasi ini. Semua data teks, daftar project, artikel, dan pengalaman kerja disimpan di sini dalam bentuk Array/JSON.

### Components (`components/`)
*   **`Navbar.tsx`**: Menu navigasi atas. Responsif (berubah menjadi hamburger menu di HP).
*   **`Hero.tsx`**: Bagian paling atas halaman utama (Intro, Foto Profil, Bio singkat). Memiliki animasi background grid bergerak.
*   **`TechStack.tsx`**: Animasi *marquee* (teks berjalan) yang menampilkan daftar keahlian/skill.
*   **`Experience.tsx`**: Bagian timeline pengalaman kerja.
*   **`Projects.tsx`**: Grid yang menampilkan daftar project di halaman utama.
*   **`ProjectDetail.tsx`**: Halaman detail ketika satu project diklik.
*   **`Articles.tsx`**: Daftar artikel di halaman utama.
*   **`ArticleDetail.tsx`**: Halaman baca artikel. Di sini terdapat logika khusus untuk **Code Block** (menambah header file dan tombol copy secara otomatis).
*   **`Contact.tsx`**: Footer dan bagian kontak di bawah halaman.

---

## 2. Panduan Mengubah Konten (Kustomisasi)

Berikut adalah panduan bagian mana yang harus diedit untuk mengubah tampilan website Anda.

### A. Mengubah Data Utama (Pengalaman, Project, Artikel)
Buka file **`constants.tsx`**.
Di sini Anda bisa mengubah isi variabel:
*   `EXPERIENCES`: Ubah role, perusahaan, dan deskripsi pekerjaan.
*   `PROJECTS`: Ubah judul, deskripsi, link demo, dan link repository.
*   `ARTICLES`: Ubah konten blog.
    *   **Penting**: Konten artikel menggunakan string HTML.
    *   Untuk membuat **Code Block dengan Header File**: Gunakan `<pre data-filename="NamaFile.js"><code>...kode...</code></pre>`.
    *   Untuk membuat **Terminal/Command Block** (tanpa header): Gunakan `<pre><code>...kode...</code></pre>` (tanpa atribut data-filename).

### B. Mengubah Foto Profil, Bio & Background Hero
Buka file **`components/Hero.tsx`**.
*   **Nama & Jabatan**: Cari teks "Halo, saya" atau "Alex Wijaya".
*   **Foto Profil**: Cari tag `<img src="...">`. Ganti URL di dalam `src` dengan URL foto Anda atau path file lokal Anda.
*   **Deskripsi**: Ubah teks di dalam tag `<p>`.
*   **Background Grid (Kotak-kotak)**:
    *   **Ketebalan Garis**: Cari kode `rgba(0, 0, 0, 0.07)`. Ubah angka `0.07` menjadi lebih besar (misal `0.1`) untuk lebih gelap, atau lebih kecil (misal `0.03`) untuk lebih tipis.
    *   **Kecepatan Animasi**: Cari properti `duration: 3`. Ubah angka `3` menjadi lebih kecil untuk mempercepat gerakan, atau lebih besar untuk memperlambat.

### C. Mengubah Logo & Menu Navigasi
Buka file **`components/Navbar.tsx`**.
*   **Logo**: Cari teks `ALEX.DEV` dan ubah sesuai nama brand Anda.
*   **Link Navigasi**: Jika ingin menambah menu, edit array `navLinks`.

### D. Mengubah Daftar Skill (Tech Stack)
Buka file **`constants.tsx`** dan cari variabel `SKILLS`.
*   Tambah atau hapus item di dalam array tersebut. Logo/Icon di TechStack hanya berupa teks, jika ingin icon gambar perlu modifikasi kode di `TechStack.tsx`.

### E. Mengubah Link Sosial Media
Buka file **`constants.tsx`** dan cari variabel `SOCIAL_LINKS`.
*   Ganti URL dengan link profil LinkedIn, GitHub, atau Twitter Anda.

---

## 3. Panduan Deployment ke VPS (Ubuntu + Nginx)

Karena aplikasi ini menggunakan struktur modern tanpa *build tool* berat (menggunakan Import Maps via CDN), deployment-nya cukup sederhana namun harus dikonfigurasi agar Routing (pindah halaman) bekerja dengan baik.

**Prasyarat:**
1.  VPS dengan OS Ubuntu (misal: DigitalOcean, Linode, IDCloudHost).
2.  Domain (opsional, bisa pakai IP VPS).
3.  Akses SSH ke VPS.

### Langkah 1: Persiapan Server
Masuk ke VPS Anda via terminal:
```bash
ssh root@ip-vps-anda
```

Update sistem dan install Nginx:
```bash
sudo apt update
sudo apt install nginx -y
```

### Langkah 2: Upload File Website
Anda bisa menggunakan Git (jika kode ada di GitHub) atau SCP/FileZilla. Kita asumsikan menggunakan direktori `/var/www/portfolio`.

1.  Buat folder:
    ```bash
    mkdir -p /var/www/portfolio
    ```
2.  Upload semua file project Anda ke folder tersebut. Struktur akhirnya harus seperti ini:
    ```
    /var/www/portfolio/
    ├── index.html
    ├── index.tsx
    ├── App.tsx
    ├── types.ts
    ├── constants.tsx
    ├── metadata.json
    ├── MANUAL.md
    └── components/
        ├── ... (file komponen)
    ```

### Langkah 3: Konfigurasi Nginx
Kita perlu memberi tahu Nginx cara melayani aplikasi React (Single Page Application).

1.  Buat file konfigurasi baru:
    ```bash
    nano /etc/nginx/sites-available/portfolio
    ```

2.  Paste konfigurasi berikut:
    ```nginx
    server {
        listen 80;
        server_name domain-anda.com www.domain-anda.com; # Ganti dengan Domain atau IP VPS

        root /var/www/portfolio;
        index index.html;

        # Gzip Compression (Agar load website cepat)
        gzip on;
        gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;

        location / {
            # PENTING: Ini agar React Router bekerja saat di-refresh
            try_files $uri $uri/ /index.html;
        }

        # Cache control untuk file statis (opsional)
        location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
            expires 30d;
            add_header Cache-Control "public, no-transform";
        }
    }
    ```

3.  Simpan (Ctrl+X, Y, Enter).

4.  Aktifkan konfigurasi:
    ```bash
    ln -s /etc/nginx/sites-available/portfolio /etc/nginx/sites-enabled/
    rm /etc/nginx/sites-enabled/default  # Hapus config default jika tidak dipakai
    ```

5.  Cek konfigurasi dan restart Nginx:
    ```bash
    nginx -t
    systemctl restart nginx
    ```

### Langkah 4: Pasang SSL (HTTPS) - Opsional tapi Disarankan
Jika Anda menggunakan domain, gunakan Certbot untuk HTTPS gratis.

```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot --nginx -d domain-anda.com -d www.domain-anda.com
```

### Selesai!
Akses domain atau IP VPS Anda di browser. Website portfolio Anda sekarang sudah online.

---

### Catatan Tambahan (Troubleshooting)
*   **Error 404 saat refresh halaman**: Pastikan baris `try_files $uri $uri/ /index.html;` ada di config Nginx. Ini memaksa server mengembalikan `index.html` untuk semua rute, sehingga React bisa menangani routingnya.
*   **Gambar tidak muncul**: Pastikan path gambar di `constants.tsx` benar. Jika menggunakan gambar lokal, pastikan file gambar juga di-upload ke server.
